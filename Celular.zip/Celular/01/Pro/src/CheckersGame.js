import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';

const { width } = Dimensions.get('window');
const BOARD_SIZE = Math.min(width - 40, 400);
const SQUARE_SIZE = BOARD_SIZE / 8;

const CheckersGame = () => {
  const [board, setBoard] = useState(initializeBoard());
  const [selectedPiece, setSelectedPiece] = useState(null);
  const [currentPlayer, setCurrentPlayer] = useState('red');
  const [showSettings, setShowSettings] = useState(false);
  const [boardColor1, setBoardColor1] = useState('#f0d9b5');
  const [boardColor2, setBoardColor2] = useState('#b58863');
  const [redPieceColor, setRedPieceColor] = useState('#dc2626');
  const [blackPieceColor, setBlackPieceColor] = useState('#1f2937');
  const [mustCapture, setMustCapture] = useState(null);

  function initializeBoard() {
    const b = Array(8).fill(null).map(() => Array(8).fill(null));
    
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 8; col++) {
        if ((row + col) % 2 === 1) {
          b[row][col] = { color: 'black', isKing: false };
        }
      }
    }
    
    for (let row = 5; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        if ((row + col) % 2 === 1) {
          b[row][col] = { color: 'red', isKing: false };
        }
      }
    }
    
    return b;
  }

  function getValidMoves(row, col, boardState = board, captureOnly = false) {
    const piece = boardState[row][col];
    if (!piece) return [];
    
    const moves = [];
    const directions = piece.isKing 
      ? [[-1, -1], [-1, 1], [1, -1], [1, 1]]
      : piece.color === 'red' 
        ? [[-1, -1], [-1, 1]]
        : [[1, -1], [1, 1]];
    
    for (const [dr, dc] of [[-1, -1], [-1, 1], [1, -1], [1, 1]]) {
      if (piece.isKing) {
        for (let dist = 1; dist < 8; dist++) {
          const midRow = row + dr * dist;
          const midCol = col + dc * dist;
          
          if (midRow < 0 || midRow >= 8 || midCol < 0 || midCol >= 8) break;
          
          const midPiece = boardState[midRow][midCol];
          
          if (midPiece) {
            if (midPiece.color !== piece.color) {
              for (let landDist = 1; landDist < 8; landDist++) {
                const jumpRow = midRow + dr * landDist;
                const jumpCol = midCol + dc * landDist;
                
                if (jumpRow < 0 || jumpRow >= 8 || jumpCol < 0 || jumpCol >= 8) break;
                
                if (!boardState[jumpRow][jumpCol]) {
                  moves.push({ 
                    row: jumpRow, 
                    col: jumpCol, 
                    capture: { row: midRow, col: midCol } 
                  });
                } else {
                  break;
                }
              }
            }
            break;
          }
        }
      } else {
        const jumpRow = row + dr * 2;
        const jumpCol = col + dc * 2;
        const midRow = row + dr;
        const midCol = col + dc;
        
        if (jumpRow >= 0 && jumpRow < 8 && jumpCol >= 0 && jumpCol < 8) {
          const midPiece = boardState[midRow][midCol];
          if (midPiece && midPiece.color !== piece.color && !boardState[jumpRow][jumpCol]) {
            moves.push({ 
              row: jumpRow, 
              col: jumpCol, 
              capture: { row: midRow, col: midCol } 
            });
          }
        }
      }
    }
    
    if (!captureOnly && moves.length === 0) {
      for (const [dr, dc] of directions) {
        if (piece.isKing) {
          for (let dist = 1; dist < 8; dist++) {
            const newRow = row + dr * dist;
            const newCol = col + dc * dist;
            
            if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) break;
            
            if (!boardState[newRow][newCol]) {
              moves.push({ row: newRow, col: newCol, capture: null });
            } else {
              break;
            }
          }
        } else {
          const newRow = row + dr;
          const newCol = col + dc;
          
          if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
            if (!boardState[newRow][newCol]) {
              moves.push({ row: newRow, col: newCol, capture: null });
            }
          }
        }
      }
    }
    
    return moves;
  }

  function hasCaptures(color, boardState = board) {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = boardState[row][col];
        if (piece && piece.color === color) {
          const moves = getValidMoves(row, col, boardState, false);
          if (moves.some(m => m.capture)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  function handleSquareClick(row, col) {
    if (mustCapture) {
      const validMoves = getValidMoves(mustCapture.row, mustCapture.col);
      const captureMove = validMoves.find(m => m.row === row && m.col === col && m.capture);
      
      if (captureMove) {
        const newBoard = board.map(r => [...r]);
        const piece = newBoard[mustCapture.row][mustCapture.col];
        
        newBoard[row][col] = piece;
        newBoard[mustCapture.row][mustCapture.col] = null;
        newBoard[captureMove.capture.row][captureMove.capture.col] = null;
        
        if ((piece.color === 'red' && row === 0) || 
            (piece.color === 'black' && row === 7)) {
          newBoard[row][col].isKing = true;
        }
        
        setBoard(newBoard);
        
        const furtherCaptures = getValidMoves(row, col, newBoard, false).filter(m => m.capture);
        
        if (furtherCaptures.length > 0) {
          setMustCapture({ row, col });
          setSelectedPiece({ row, col });
        } else {
          setMustCapture(null);
          setSelectedPiece(null);
          setCurrentPlayer(currentPlayer === 'red' ? 'black' : 'red');
        }
      }
      return;
    }
    
    if (selectedPiece) {
      const validMoves = getValidMoves(selectedPiece.row, selectedPiece.col);
      const move = validMoves.find(m => m.row === row && m.col === col);
      
      if (move) {
        const newBoard = board.map(r => [...r]);
        const piece = newBoard[selectedPiece.row][selectedPiece.col];
        
        newBoard[row][col] = piece;
        newBoard[selectedPiece.row][selectedPiece.col] = null;
        
        if (move.capture) {
          newBoard[move.capture.row][move.capture.col] = null;
        }
        
        if ((piece.color === 'red' && row === 0) || 
            (piece.color === 'black' && row === 7)) {
          newBoard[row][col].isKing = true;
        }
        
        setBoard(newBoard);
        
        if (move.capture) {
          const furtherCaptures = getValidMoves(row, col, newBoard, false).filter(m => m.capture);
          
          if (furtherCaptures.length > 0) {
            setMustCapture({ row, col });
            setSelectedPiece({ row, col });
            return;
          }
        }
        
        setSelectedPiece(null);
        setMustCapture(null);
        setCurrentPlayer(currentPlayer === 'red' ? 'black' : 'red');
      } else {
        setSelectedPiece(null);
      }
    } else {
      const piece = board[row][col];
      if (piece && piece.color === currentPlayer) {
        const playerHasCaptures = hasCaptures(currentPlayer);
        const pieceHasCaptures = getValidMoves(row, col).some(m => m.capture);
        
        if (playerHasCaptures && !pieceHasCaptures) {
          return;
        }
        
        setSelectedPiece({ row, col });
      }
    }
  }

  function resetGame() {
    setBoard(initializeBoard());
    setSelectedPiece(null);
    setCurrentPlayer('red');
    setMustCapture(null);
  }

  const validMoves = selectedPiece ? getValidMoves(selectedPiece.row, selectedPiece.col) : [];
  const playerHasCaptures = hasCaptures(currentPlayer);

  const ColorPicker = ({ label, value, onChange }) => {
    const colors = [
      '#f0d9b5', '#b58863', '#dc2626', '#1f2937',
      '#ef4444', '#000000', '#ffffff', '#f59e0b',
      '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'
    ];

    return (
      <View style={styles.colorPickerContainer}>
        <Text style={styles.colorLabel}>{label}</Text>
        <View style={styles.colorGrid}>
          {colors.map((color) => (
            <TouchableOpacity
              key={color}
              onPress={() => onChange(color)}
              style={[
                styles.colorOption,
                { backgroundColor: color },
                value === color && styles.colorOptionSelected
              ]}
            />
          ))}
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Damas</Text>
          <View style={styles.headerButtons}>
            <TouchableOpacity
              onPress={() => setShowSettings(!showSettings)}
              style={styles.button}
            >
              <Text style={styles.buttonText}>⚙️</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={resetGame}
              style={styles.button}
            >
              <Text style={styles.buttonText}>🔄</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.turnContainer}>
          <Text style={styles.turnText}>
            Turno: <Text style={[styles.turnPlayer, { color: currentPlayer === 'red' ? redPieceColor : blackPieceColor }]}>
              {currentPlayer === 'red' ? 'Vermelho' : 'Preto'}
            </Text>
          </Text>
          {mustCapture && (
            <Text style={styles.warningText}>Continue capturando!</Text>
          )}
          {playerHasCaptures && !mustCapture && (
            <Text style={styles.warningText}>Captura obrigatória!</Text>
          )}
        </View>

        {showSettings && (
          <View style={styles.settingsPanel}>
            <Text style={styles.settingsTitle}>Personalizar Cores</Text>
            <ColorPicker 
              label="Casa Clara:" 
              value={boardColor1} 
              onChange={setBoardColor1} 
            />
            <ColorPicker 
              label="Casa Escura:" 
              value={boardColor2} 
              onChange={setBoardColor2} 
            />
            <ColorPicker 
              label="Peças Vermelhas:" 
              value={redPieceColor} 
              onChange={setRedPieceColor} 
            />
            <ColorPicker 
              label="Peças Pretas:" 
              value={blackPieceColor} 
              onChange={setBlackPieceColor} 
            />
          </View>
        )}

        <View style={[styles.boardContainer, { width: BOARD_SIZE, height: BOARD_SIZE }]}>
          {board.map((row, rowIndex) => (
            <View key={rowIndex} style={styles.row}>
              {row.map((piece, colIndex) => {
                const isLight = (rowIndex + colIndex) % 2 === 0;
                const isSelected = selectedPiece?.row === rowIndex && selectedPiece?.col === colIndex;
                const isValidMove = validMoves.some(m => m.row === rowIndex && m.col === colIndex);
                
                return (
                  <TouchableOpacity
                    key={`${rowIndex}-${colIndex}`}
                    onPress={() => handleSquareClick(rowIndex, colIndex)}
                    style={[
                      styles.square,
                      {
                        width: SQUARE_SIZE,
                        height: SQUARE_SIZE,
                        backgroundColor: isLight ? boardColor1 : boardColor2,
                      },
                      isSelected && styles.selectedSquare
                    ]}
                  >
                    {piece && (
                      <View
                        style={[
                          styles.piece,
                          {
                            backgroundColor: piece.color === 'red' ? redPieceColor : blackPieceColor,
                          }
                        ]}
                      >
                        {piece.isKing && (
                          <Text style={styles.kingIcon}>♔</Text>
                        )}
                      </View>
                    )}
                    {isValidMove && (
                      <View style={styles.validMoveIndicator} />
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </View>

        <View style={styles.legend}>
          <Text style={styles.legendText}>
            Dama move-se em qualquer distância na diagonal • Capturas múltiplas obrigatórias
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1f2937',
  },
  content: {
    padding: 20,
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  button: {
    backgroundColor: '#374151',
    padding: 10,
    borderRadius: 8,
  },
  buttonText: {
    fontSize: 24,
  },
  turnContainer: {
    backgroundColor: '#374151',
    borderRadius: 8,
    padding: 15,
    width: '100%',
    marginBottom: 20,
    alignItems: 'center',
  },
  turnText: {
    color: '#ffffff',
    fontSize: 18,
  },
  turnPlayer: {
    fontWeight: 'bold',
  },
  warningText: {
    color: '#fbbf24',
    fontSize: 14,
    marginTop: 5,
  },
  settingsPanel: {
    backgroundColor: '#374151',
    borderRadius: 8,
    padding: 15,
    width: '100%',
    marginBottom: 20,
  },
  settingsTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  colorPickerContainer: {
    marginBottom: 15,
  },
  colorLabel: {
    color: '#ffffff',
    fontSize: 14,
    marginBottom: 8,
  },
  colorGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  colorOption: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  colorOptionSelected: {
    borderColor: '#fbbf24',
    borderWidth: 3,
  },
  boardContainer: {
    backgroundColor: '#111827',
    padding: 5,
    borderRadius: 8,
  },
  row: {
    flexDirection: 'row',
  },
  square: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedSquare: {
    borderWidth: 3,
    borderColor: '#fbbf24',
  },
  piece: {
    width: '75%',
    height: '75%',
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  kingIcon: {
    color: '#ffffff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  validMoveIndicator: {
    position: 'absolute',
    width: '33%',
    height: '33%',
    borderRadius: 100,
    backgroundColor: '#10b981',
    opacity: 0.6,
  },
  legend: {
    backgroundColor: '#374151',
    borderRadius: 8,
    padding: 15,
    marginTop: 20,
    width: '100%',
  },
  legendText: {
    color: '#ffffff',
    fontSize: 12,
    textAlign: 'center',
  },
});

export default CheckersGame;