import React from 'react';
import CheckersGame from './src/CheckersGame';

function App() {
  return <CheckersGame />;
}

export default App;