# 📱 Passo a Passo Completo - React Native
## PARTE 1: Configurar Ambiente
### 1. Instalar Node.js (se ainda não tem)

* Baixe: https://nodejs.org/
* Versão LTS recomendada

### 2. Instalar Java JDK

* Baixe o JDK 17: https://www.oracle.com/java/technologies/downloads/#java17
* Instale e configure a variável de ambiente `JAVA_HOME`

### 3. Instalar Android Studio

* Baixe: https://developer.android.com/studio
* Durante instalação, marque:
    * Android SDK 
    * Android SDK Platform
    * Android Virtual Device


### 4. Configurar SDK do Android
No Android Studio:

* Abra **Settings** (ou **Preferences** no Mac)
* Vá em **Appearance & Behavior > System Settings > Android SDK**
* Na aba **SDK Platforms**, marque:
    * Android 13.0 (Tiramisu) ou superior


* Na aba **SDK Tools**, marque:
    * Android SDK Build-Tools
    * Android Emulator
    * Android SDK Platform-Tools


### 5. Configurar Variáveis de Ambiente
**Windows**:

```
ANDROID_HOME = C:\Users\SeuUsuario\AppData\Local\Android\Sdk
Path adicionar: %ANDROID_HOME%\platform-tools
Path adicionar: %ANDROID_HOME%\emulator
Path adicionar: %ANDROID_HOME%\tools\bin

```

**Mac/Linux**:
Adicione no `~/.bash_profile` ou `~/.zshrc`:

```bash
export ANDROID_HOME=$HOME/Library/Android/sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools
```
---------------------------------------------------------

## PARTE 2: Criar Projeto React Native
#### 1. Criar o Projeto

```bash
npx react-native@latest init JogoDamas
cd JogoDamas

```

#### 2. Instalar Dependências
```bash
npm install react-native-linear-gradient

```

#### 3. Criar o Componente do Jogo
Crie um arquivo `src/CheckersGame.js` com o seguinte código:

Agora crie a pasta `src` e salve o arquivo acima. Depois, substitua o conteúdo do `App.js` na raiz do projeto:

```javascript
import React from 'react';
import CheckersGame from './src/CheckersGame';

function App() {
  return <CheckersGame />;
}

export default App;

```
------------------------------------------------------

## PARTE 3: Rodar o Aplicativo
### 1. Iniciar o Metro Bundler
```bash
npm start
```
### 2. Em outro terminal, rodar no Android
```bash
npm run android
```
Ou se preferir iOS (Somente no MAC):
```bash
npm run ios

```

------------------------------------------------------

## PARTE 4: Gerar APK para Instalação
### 1. Configurar Assinatura
Navegue até `android/app` e crie um arquivo chamado `my-release-key.keystore`:

```bash
cd android/app
keytool -genkeypair -v -storetype PKCS12 -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

```
Digite uma senha quando solicitado (anote ela!).

### 2. Configurar gradle.properties
Edite `android/gradle.properties` e adicione:
```properties
MYAPP_RELEASE_STORE_FILE=my-release-key.keystore
MYAPP_RELEASE_KEY_ALIAS=my-key-alias
MYAPP_RELEASE_STORE_PASSWORD=sua_senha_aqui
MYAPP_RELEASE_KEY_PASSWORD=sua_senha_aqui

```
### 3. Configurar build.gradle
Edite `android/app/build.gradle` e adicione dentro de `android`:

```gradle
signingConfigs {
    release {
        if (project.hasProperty('MYAPP_RELEASE_STORE_FILE')) {
            storeFile file(MYAPP_RELEASE_STORE_FILE)
            storePassword MYAPP_RELEASE_STORE_PASSWORD
            keyAlias MYAPP_RELEASE_KEY_ALIAS
            keyPassword MYAPP_RELEASE_KEY_PASSWORD
        }
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled enableProguardInReleaseBuilds
        proguardFiles getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro"
    }
}

```

### 4. Gerar APK
```bash
cd android
./gradlew assembleRelease

```

O APK estará em: `android/app/build/outputs/apk/release/app-release.apk`
### 5. Instalar no Celular
* Transfira o APK para seu celular
* Habilite "Instalar apps de fontes desconhecidas" nas configurações
* Abra o APK e instale!

-----------------------------------------------------------------

**Resumo dos Comandos:**
```bash
# Criar projeto
npx react-native@latest init JogoDamas
cd JogoDamas

# Instalar deps
npm install react-native-linear-gradient

# Criar src/CheckersGame.js com o código acima
# Editar App.js na raiz

# Rodar em desenvolvimento
npm start
npm run android

# Gerar APK
cd android
./gradlew assembleRelease

```